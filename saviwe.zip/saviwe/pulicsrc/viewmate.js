
                  (function() {
                                    var meta = document.createElement('meta')
                                    meta.setAttribute('name', 'viewport')
                                    var devicePixelRatio = window.devicePixelRatio
                                    if (navigator.userAgent.match(/Le/ ||
                                            (navigator.userAgent.match(/iphone/i) && location.protocal.match(/file/)))) {
                                        var devicePixelRatio = 1
                                    }
                                    var dpr = devicePixelRatio ? (1 / devicePixelRatio) : 1
                                    document.documentElement.setAttribute('data-dpr', devicePixelRatio || 1)
                                    meta.setAttribute('content', 'width=device-width,initial-scale=' + 1 + ', maximum-scale=' + dpr + ', minimum-scale=' + dpr + ', user-scalable=no')
                                    document.head.appendChild(meta)
                                    document.addEventListener('DOMContentLoaded', function() {
                                        meta.setAttribute('content', 'width=device-width,initial-scale=' + 1 + ', maximum-scale=' + dpr + ', minimum-scale=' + dpr + ', user-scalable=no')
                                    })
                                })()
                                
                                
                                
                                var dpr = document.documentElement.getAttribute('data-dpr') || 1
                                var width = document.documentElement.offsetWidth
                                var fontSize = 100 / 750 * width;
                                document.querySelector('html').style.fontSize = (fontSize) + 'px';
                                window.addEventListener('resize', function() {
                                    var width = document.querySelector('html').offsetWidth;
                                    var fontSize = 100 / 750 * width;
                                    document.querySelector('html').style.fontSize = (fontSize) + 'px';
                                })
                            
                            /* rem转换比例为100*/  