require.config({
    paths : {
        "vue" : "../plug/vue",
        "polyfill" : "../plug/polyfill",
        "jquery" : "../plug/jquery",
       
        "common":"../plug/common"
    }
});

require(["vue","jquery","polyfill","common"],function(Vue, element, $){
	

	

	var login = new Vue({
		el:"#login",
		data:{
			title:'首页'
		},
		created:function(){

		},
		methods:{
			
			
		
			
		},
		
		
	});



});




