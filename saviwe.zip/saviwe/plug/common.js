// var server = "http://192.168.1.136:81";//服务器地址
//var server = "http://192.168.1.171:82";//服务器地址
//var server = "http://192.168.1.179:85";//服务器地址
// var server = "http://192.168.1.41:85";//服务器地址
//var server = "http://192.168.1.133:8080";//服务器地址
var server = "https://192.168.1.178"
// server = window.location.protocol + "//"+document.location.host;//服务器地址
//var server = window.location.protocol + "//"+document.domain+":8080";//服务器地址
var api_token = sessionStorage.getItem("api_token");
var api_uid = sessionStorage.getItem("uid");

var systemNotificUrl = "",
	isShowSystemNotific = false;

/**
 * 异步请求
 * @param {Object} param
 */
function myAjax(param){
	if (!param.data) param.data = {};
	if (!param.type) param.type = "post";
	if (!param.async) param.async = true;
	if (!param.dataType) param.dataType = "json";
	if (!param.error) param.error = function(XMLHttpRequest,textStatus,errorThrown){
		   if(XMLHttpRequest.status==504){
			   alert("系统操作超时!")
		   }
		   
		   if(XMLHttpRequest.status==401){
               window.location.href="system_update.html?w=false&o=8-5";
		   }
		
		console.log(XMLHttpRequest,textStatus,errorThrown); };
	if (!param.complete) param.complete = function(XMLHttpRequest){ /*console.log("完成",XMLHttpRequest);*/ };
	$.ajax({
		type:param.type,
		url:param.url,
		async:param.async,
		data:param.data,
		dataType:param.dataType,
		success:param.success,
		error:param.error,
		complete:param.complete,
		beforeSend:function(XMLHttpRequest){
			updateToken();
			XMLHttpRequest.setRequestHeader("Api-Token", api_token);
			XMLHttpRequest.setRequestHeader("UID", api_uid);
		}
	});
}

if (api_token != '') {
	getSessionTime();
	setInterval("getSessionTime()", 5000);
}

function getSessionTime()
{
	let time = sessionStorage.getItem("sa_session_time");
	time = time ? parseInt(time) : 0;
	time += 5;
	sessionStorage.setItem("sa_session_time", time);
	return time;
}

function updateToken()
{
	if (api_token != '') {
		let session_time = sessionStorage.getItem("sa_session_time");
		if (session_time > 1200) {
			$.ajax({
				url: server + '/user/token',
				async: false,
				dataType: 'json',
				type: 'post',
				data: {
					api_token: api_token,
					uid: api_uid,
				},
				success: function (data) {
					if (data.code == 200) {
						api_token = data.data.token;
						api_uid = data.data.admin_id;
						sessionStorage.setItem("api_token", data.data.token);
						sessionStorage.setItem("uid", data.data.admin_id);
						sessionStorage.setItem("sa_session_time", 0);
					}
				}
			})
		} else {
			api_token = sessionStorage.getItem("api_token");
			api_uid = sessionStorage.getItem("uid");
		}
	}
}
// 加密
function encrypt(str) {
	return $.base64.encode(str);
}

// 解密
function decrypt(str) {
	var strs = $.base64.decode(str);
	//strs = strs.replace(password_key, "");
	return strs;
}


/**
 * 文件上传-异步请求
 * @param {Object} param
 */
function ajaxUpload(param) {
	if (!param.data) param.data = {};
	if (!param.type) param.type = "post";
	if (!param.error) param.error = function(XMLHttpRequest, textStatus, errorThrown) {
		console.log(XMLHttpRequest, textStatus, errorThrown);
	};
	if (!param.complete) param.complete = function(XMLHttpRequest) {};
	$.ajax({
		type: param.type,
		url: param.url,
		cache: false,
		data: param.data,
		processData: false,
		contentType: false,
		success: param.success,
		error: param.error,
		complete: param.complete,
		beforeSend: function(XMLHttpRequest) {
			XMLHttpRequest.setRequestHeader("Api-Token", api_token);
		}
	});
}

function getJson(param) {
	if (!param.error) param.error = function(XMLHttpRequest, textStatus, errorThrown) {
		console.log(XMLHttpRequest, textStatus, errorThrown);
	};
	if (!param.complete) param.complete = function(XMLHttpRequest) {};
	$.ajax({
		url: param.url,
		type: "get",
		dataType: "json", //jsonp数据类型
		jsonp: "callback", //服务端用于接收callback调用的function名的参数
		jsonpCallback: "message",
		success: param.success,
		error: param.error,
		complete: param.complete
	});
}

/**
 * 导出Excel文件
 * @param {Object} param  requestUrl:接口地址，param.param：接口参数
 */
function downLoadExcel(param) {
	var dataParams = param.param;
	var exportExcel = "export_excel";
	dataParams[exportExcel] = 1;
	var params = $.param(dataParams);
	var inputStr = "";
	for (var i in dataParams) {
		inputStr += '<input type="hidden" name="' + i + '" value="' + dataParams[i] + '">';
		//inputStr += '<input type="hidden" name="'+ i +'" value="'+ dataParams[i] +'"><input type="hidden" name="api_token" value="'+api_token+'">';
	}
	var url = param.requestUrl;
	$('<form method="post" action="' + url + '">' + inputStr + '</form>').appendTo('body').submit().remove();
	delete dataParams[exportExcel];
}


/**
 * 获取url中的参数值
 * @param {Object} name 参数名
 */
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}

/**
 * 获取字符串长度
 * @param {Object} str
 */
function getStrlength(str) {
	var realLength = 0,
		len = str.length,
		charCode = -1;
	for (var i = 0; i < len; i++) {
		charCode = str.charCodeAt(i);
		if (charCode >= 0 && charCode <= 128) {
			realLength += 1;
		} else {
			realLength += 2;
		}
	}
	return realLength;
}

/**
 * 将全角转换为半角
 */
String.prototype.dbc2sbc = function() {
	return this.replace(/[\uff01-\uff5e]/g, function(a) {
		return String.fromCharCode(a.charCodeAt(0) - 65248);
	}).replace(/\u3000/g, " ");
}


/**
 * 消息通知
 * @param {Object} title 标题
 * @param {Object} content 内容
 * @param {Object} time 时间
 */
var notificationTimer = "";

function notification(title, content, time) {
	clearTimeout(notificationTimer);
	if ($("#notificationBox").length > 0) {
		$("#notificationBox").show();
		$("#notificationBox").find(".notificationBox-title>p").text(title);
		$("#notificationBox").find(".notificationBox-content").text(content);
		$("#notificationBox").find(".notificationBox-footer").text(time);
	} else {
		$("body").append(
			'<div class="notificationBox" id="notificationBox" style="z-index:9999;"><div class="notificationBox-title"><p>' +
			title + '</p><i class="el-icon-close" id="notificationBoxClose"></i></div><div class="notificationBox-content">' +
			content + '</div><div class="notificationBox-footer">' + time + '</div></div>');
	}
	$("#notificationBoxClose").on("click", function() {
		$("#notificationBox").remove();
	});
	notificationTimer = setTimeout(function() {
		$("#notificationBox").remove();
	}, 3000);
}

/**
 * 格式化日期  MM/dd HH:mm:ss
 * @param {Object} now 时间戳
 */
function formatDate(now, flag) {
	now = parseInt(now) || Date.parse(now);
	now = new Date(now);
	var year = now.getFullYear(),
		month = now.getMonth() + 1,
		date = now.getDate(),
		hour = now.getHours(),
		minute = now.getMinutes(),
		second = now.getSeconds();
	month = month < 10 ? "0" + month : month;
	date = date < 10 ? "0" + date : date;
	hour = hour < 10 ? "0" + hour : hour;
	minute = minute < 10 ? "0" + minute : minute;
	second = second < 10 ? "0" + second : second;
	if (flag == 0) {
		return year + "-" + month + "-" + date;
	} else if (flag == 1) {
		return hour + ":" + minute + ":" + second;
	} else if (flag == 2) {
		return year + "/" + month + "/" + date + " " + hour + ":" + minute + ":" + second;
	} else if (flag == 3) {
		return year + "-" + month;
	} else if (flag == 4) {
		return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
	} else if (flag == 5) {
		return year + "-" + month + "-" + date + " " + hour + ":" + minute;
	} else {
		return month + "/" + date + " " + hour + ":" + minute + ":" + second;
	}
}

/**
 * 获取当前完整日期 yyyy/MM/dd HH:mm:ss
 */


function getNowAllFormatDate(datetime) {
	var date = datetime == undefined ? new Date() : datetime;
	var year = date.getFullYear();
	/* 在日期格式中，月份是从0开始的，因此要加0
	 * 使用三元表达式在小于10的前面加0，以达到格式统一  如 09:11:05
	 * */
	var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
	var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
	var hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
	var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
	var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
	// 拼接
	return year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds

}

/**
 * 日期范围格式化
 * @param {Object} value
 */
function timeRange(value, flag) {
	if (flag != true) {
		value = value.join(" - ");
	}
	var reg = new RegExp("/", "g");
	value = value.replace(reg, "/");
	return value;
}

/**
 * title
 * @param {Object} Vue
 * @param {Object} element
 * @param {Object} $
 */
function appTitle(Vue, element, $) {
	var commonTitle = new Vue({
		el: "#apptitle",
		data: {
			title: ""
		}
	});
	return commonTitle;
}


/**
 * 通用头部
 * @param {Object} Vue
 * @param {Object} element
 * @param {Object} $
 * @param {Object} systemSettings 系统设置
 */
function headerBanner(Vue, element, $, commonFooter, commonTitle) {
	//头部
	var commonHeader = new Vue({
		el: "#common-header",
		data: {
			isShowHeader: true,
			logoUrl: "",
			title: "",
			roleName: "您好，" + sessionStorage.getItem("who"),
			//			roleName:"您好，系统管理员",
			dialogVisible: false,
			isStartQuit: false,
			isShowNotificNum: false,
			systemNotificNum: 0,
			isShowSystemNotific: isShowSystemNotific,
			isStartNoticenum: true,
			isStartLogoinfo: true
		},
		created: function() {
			//			this.roleName = "您好，" + sessionStorage.getItem("who");
		},
		methods: {
			quitSystem: function() { //退出
				var that = this;
				if (this.isStartQuit == false) {
					this.isStartQuit = true;
					myAjax({
						url: server + "/index/layout",
						success: function(data) {
							if (data.code == 200) {
								sessionStorage.setItem("tree", "");
								sessionStorage.setItem("logo", "");
								window.location.href = "../index.html";
							}
							if (data.code == 401) { //登陆超时
								errorPage(data.msg);
							}
						},
						complete: function() {
							that.isStartQuit = false;
						}
					});
				}
			},
			logoinfoGet: function() { //logo信息
				var that = this;
				if (sessionStorage.getItem("logo")) {
					var data = JSON.parse(sessionStorage.getItem("logo"));
					if (data.code == 401) {
						errorPage(data.msg); /*登录超时*/
					}
					if (data.code == 200) {
						sessionStorage.setItem("logo", JSON.stringify(data));
						if (data.data.web_logo == "") {
							that.logoUrl = "../images/comment/logo.png";
						} else {
							that.logoUrl = server + data.data.web_logo;
						}
						if (data.data.web_title == "") {
							that.title = "互联网出口审计管理平台";
							if (commonTitle) commonTitle.title = "互联网出口审计管理平台";
						} else {
							that.title = data.data.web_title;
							if (commonTitle) commonTitle.title = data.data.web_title;
						}
						commonFooter.version = "Copyright © 2019 All Rights Reserved " + data.data.web_copyright;
					}
					return false;
				}
				if (this.isStartLogoinfo == true) {
					this.isStartLogoinfo = false;
					myAjax({
						url: server + "/noauth/logoinfo",
						data: {
							default_type: ""
						},
						success: function(data) {
							if (data.code == 401) {
								errorPage(data.msg); /*登录超时*/
							}
							if (data.code == 200) {
								sessionStorage.setItem("logo", JSON.stringify(data));
								if (data.data.web_logo == "") {
									that.logoUrl = "../images/comment/logo.png";
								} else {
									that.logoUrl = server + data.data.web_logo;
								}
								if (data.data.web_title == "") {
									that.title = "互联网出口审计管理平台";
									if (commonTitle) commonTitle.title = "互联网出口审计管理平台";
								} else {
									that.title = data.data.web_title;
									if (commonTitle) commonTitle.title = data.data.web_title;
								}
								commonFooter.version = "Copyright © 2018 All Rights Reserved " + data.data.web_copyright;
							}
						},
						complete: function() {
							that.isStartLogoinfo = true;
						}
					});
				}
			}
		}
	});
	return commonHeader;
}


/**
 * 提示框
 * @param {Object} content 内容
 */
var miniNotifyTimer = "";

function miniNotify(content) {
	clearTimeout(miniNotifyTimer);
	if ($("#miniNotify").length > 0) {
		$("#miniNotify").show();
		$("#miniNotify").find(".notificationBox-content").text(content);
	} else {
		$("body").append(
			'<div class="notificationBox" id="miniNotify" style="z-index:9999;"><div class="notificationBox-title" style="background:#FFFFFF;"><i class="el-icon-close" id="miniNotifyClose"></i></div><div class="notificationBox-content">' +
			content + '</div></div>');
	}
	$("#miniNotifyClose").on("click", function() {
		$("#miniNotify").remove();
	});
	miniNotifyTimer = setTimeout(function() {
		$("#miniNotify").remove();
	}, 3000);
}

/**
 * 登陆超时
 */
function errorPage(msg) {
    var api_token = sessionStorage.getItem("api_token");
	var api_uid = sessionStorage.getItem("uid");
	var api_token = sessionStorage.getItem("api_token");
	var api_uid = sessionStorage.getItem("uid");
	
	if(!api_token || !api_uid){
		window.location.href = "/index.html";
	} else {
		window.location.href = "error.html";
		sessionStorage.setItem("etime", 5);
		sessionStorage.setItem("errormsg", msg);
	}	

	
}

/**
 * 获取当前页面名称，带后缀名
 */
function pageName() {
	var strUrl = window.location.href;
	var arrUrl = strUrl.split("/");
	var strPage = arrUrl[arrUrl.length - 1];
	return strPage;
}

/**
 * 通用页脚
 * @param {Object} Vue
 * @param {Object} element
 * @param {Object} $
 */
function generalFooter(Vue, element, $) {
	//页脚
	var commonFooter = new Vue({
		el: "#common-footer",
		data: {
			isShowFooter: true,
			footerStyle: "",
			version: ""
		},
		created: function() {

		},
		methods: {

		}
	});
	return commonFooter;
}


/**
 * 通用-主菜单部分
 * @param {Object} Vue
 * @param {Object} element
 * @param {Object} $
 * @param {Object} main 主要内容
 * @param {Object} isCollapse 是否为图标菜单，true为是
 * @param {Object} CollapseOffWidth 图标菜单的宽度
 * @param {Object} CollapseOnWidth 非图标菜单的宽度
 * @param {Object} menuContent 主菜单的宽度
 * @param {Object} hrefUrl 子菜单的跳转URL
 */
function generalMenu(Vue, element, $, main, isCollapse, CollapseOffWidth, CollapseOnWidth, callback) {
	//主菜单
	var commonMenu = new Vue({
		el: "#common-menu",
		data: {
			isShowMenu: true,
			isCollapse: isCollapse,
			defaultActive: getQueryString("o"),
			commonMenuStyle: "",
			commonMenuWidth: "width:" + CollapseOffWidth,
			commonMenuHeight: "",
			commonMenuBg1: "width:" + CollapseOnWidth,
			commonMenuBg2: "width:" + CollapseOffWidth,
			isSecurityGuard: false, //是否为安全保密员角色
			indexMenu: "", //首页
			menuContent: [], //主菜单内容
			iconClass: [
				"common-menu-icon common-menu-icon-audit",
				"common-menu-icon common-menu-icon-strategy",
				"common-menu-icon common-menu-icon-system",
				"common-menu-icon common-menu-icon-strategy"
			],
			hrefUrl: [],
			isShowSystemNotific: false
		},
		created: function() {
			if (sessionStorage.getItem("isSecurityGuard") == "false") {
				this.isSecurityGuard = false;
			} else if (sessionStorage.getItem("isSecurityGuard") == "true") {
				this.isSecurityGuard = true;
			}
			var that = this;
			if (sessionStorage.getItem("tree")) {
				var tree = JSON.parse(sessionStorage.getItem("tree"));
				this.menuContent = treeMenu(tree, that.menuContent, that.iconClass, that);
				callback(that);
			} else {
				myAjax({
					url: server + "/user/menu",
					type: "post",
					success: function(data) {
						if (data.code == 401) {
							errorPage(data.msg);
						} //登陆超时
						if (data.code == 200) {
							sessionStorage.setItem("tree", JSON.stringify(data.data));
							that.menuContent = treeMenu(data.data, that.menuContent, that.iconClass, that);
							callback(that);
						}
					},
					complete: function() {

					}
				});
			}
		},
		methods: {
			handleOpen: function(key, keyPath) { //展开二级菜单

			},
			handleClose: function(key, keyPath) { //收起二级菜单

			},

			beginShowMenu: function() { //全屏的情况下展开菜单
				if (main.isFullscreen) {
					this.isShowMenu = true;
					if (this.isCollapse) {
						$("#common-menu").css({
							width: CollapseOffWidth
						});
						$("#main").css({
							paddingLeft: CollapseOffWidth
						});
					} else {
						$("#common-menu").css({
							width: CollapseOnWidth
						});
						$("#main").css({
							paddingLeft: CollapseOnWidth
						});
					}
				}
				try {
					main.resizeEcharts();
				} catch (e) {
					//TODO handle the exception
				}
			},
			endShowMenu: function() { //全屏的情况下收缩菜单
				if (main.isFullscreen) {
					this.isShowMenu = false;
					$("#common-menu").css({
						width: "0px"
					});
					$("#main").css({
						paddingLeft: $("#common-menu").width() + "px"
					});
				}
				try {
					main.resizeEcharts();
				} catch (e) {
					//TODO handle the exception
				}
			},
			commonMenuSelect: function() { //点击收缩菜单图标
				try {
					main.resizeEcharts();
				} catch (e) {
					//TODO handle the exception
				}
				this.isCollapse = !this.isCollapse;
				if (this.isCollapse) { //图标菜单
					main.mainStyle = "padding-left:" + CollapseOffWidth + ";";
					commonFooter.footerStyle = "padding-left:" + CollapseOffWidth + ";";
					this.commonMenuWidth = "width:" + CollapseOffWidth;
					this.commonMenuStyle = "width:" + CollapseOffWidth;
					$(".menubox").css({
						width: CollapseOffWidth
					});
				} else { //图标+文字菜单
					main.mainStyle = "padding-left:" + CollapseOnWidth + ";";
					commonFooter.footerStyle = "padding-left:" + CollapseOnWidth + ";";
					this.commonMenuWidth = "width:" + CollapseOnWidth;
					this.commonMenuStyle = "width:" + CollapseOnWidth;
					$(".menubox").css({
						width: CollapseOnWidth
					});
				}
			},
			menuSelect: function(key, keyPath) { //点击菜单跳转
				for (var i = 0; i < this.hrefUrl.length; i++) {
					if (key == this.hrefUrl[i].key && this.hrefUrl) {
						if (this.hrefUrl[i].url) {
							window.location.href = this.hrefUrl[i].url + "?w=" + this.isCollapse + "&o=" + key;
							break;
						}
					}
				}
			}
		}
	});
	return commonMenu;
}

/**
 * 菜单内容遍历
 * @param {Object} tree 后台数据
 * @param {Object} menuContent 前端显示内容
 * @param {Object} iconClass 图标
 * @param {Object} that 对象
 */
function treeMenu(tree, menuContent, iconClass, that) {
	console.log(tree)
	var a = [];
	that.indexMenu = "首页";
	that.isSecurityGuard = true;
	a.push({
		key: 1,
		url: "home.html",
		index: 1
	});
	/*for(var i=0; i<tree.length; i++){
		if (tree[i].h_layer == 1) {//一级
			menuContent.push({
				titleIndex:tree[i].id,
				title:tree[i].name,
				iconClass:iconClass[i],
				item:[]
			});
			if(tree[i].son){
				for(var j=0; j<tree[i].son.length; j++){
					menuContent[i].item.push({
						itemIndex:tree[i].son[j].parentid,
						itemTitle:tree[i].son[j].name,
						url:tree[i].son[j].url
					});
				}
			}
		}
	}*/
	for (var i = 0; i < tree.length; i++) {
		menuContent.push({
			titleIndex: tree[i].id,
			title: tree[i].name,
			iconClass: iconClass[i],
			item: []
		});
		if (tree[i].son) {
			for (var j = 0; j < tree[i].son.length; j++) {
				if (tree[i].son[j].url) {
					menuContent[i].item.push({
						itemIndex: tree[i].son[j].parentid + "-" + tree[i].son[j].id,
						itemTitle: tree[i].son[j].name,
						url: tree[i].son[j].url
					});
				} else {
					menuContent[i].item.push({
						itemIndex: tree[i].son[j].parentid + "-" + tree[i].son[j].id,
						itemTitle: tree[i].son[j].name,
						item: []
					});
				}
				if (tree[i].son[j].son) {
					for (var k = 0; k < tree[i].son[j].son.length; k++) {
						if (menuContent[i].item[j].item) {
							menuContent[i].item[j].item.push({
								itemIndex: tree[i].id + "-" + tree[i].son[j].son[k].parentid + "-" + tree[i].son[j].son[k].id,
								itemTitle: tree[i].son[j].son[k].name,
								url: tree[i].son[j].son[k].url
							});
						}
					}
				}
			}
		}
	}
	for (var j = 0; j < menuContent.length; j++) {
		for (var k = 0; k < menuContent[j].item.length; k++) {
			//			menuContent[j].item[k].itemIndex = menuContent[j].item[k].itemIndex + "-" + (k+1);
			if (menuContent[j].item[k].url) {
				a.push({
					key: menuContent[j].item[k].itemIndex,
					url: menuContent[j].item[k].url,
					index: menuContent[j].item[k].itemIndex.split("-")[0]
				});
			}
			if (menuContent[j].item[k].item) {
				for (var g = 0; g < menuContent[j].item[k].item.length; g++) {
					a.push({
						key: menuContent[j].item[k].item[g].itemIndex,
						url: menuContent[j].item[k].item[g].url,
						index: menuContent[j].item[k].item[g].itemIndex.split("-")[0]
					});
				}
			}
		}
	}
	that.hrefUrl = [];
	that.hrefUrl = a;
	console.log(menuContent)
	return menuContent;
}

/**
 * 菜单内容遍历
 * @param {Object} tree 后台数据
 * @param {Object} menuContent 前端显示内容
 * @param {Object} iconClass 图标
 * @param {Object} that 对象
 */
function treeMenu2(tree, menuContent, iconClass, that) {
	console.log(tree)
	var a = [];
	that.indexMenu = "首页";
	that.isSecurityGuard = true;
	a.push({
		key: 1,
		url: "home.html",
		index: 1
	});
	for (var i = 0; i < tree.length; i++) {
		menuContent.push({
			titleIndex: tree[i].id,
			title: tree[i].name,
			iconClass: iconClass[i],
			item: []
		});
		if (tree[i].son) {
			for (var j = 0; j < tree[i].son.length; j++) {
				if (tree[i].son[j].url) {
					menuContent[i].item.push({
						itemIndex: tree[i].son[j].parentid + "-" + tree[i].son[j].id,
						itemTitle: tree[i].son[j].name,
						url: tree[i].son[j].url
					});
				} else {
					menuContent[i].item.push({
						itemIndex: tree[i].son[j].parentid + "-" + tree[i].son[j].id,
						itemTitle: tree[i].son[j].name,
						item: []
					});
				}
				if (tree[i].son[j].son) {
					for (var k = 0; k < tree[i].son[j].son.length; k++) {
						if (menuContent[i].item[j].item) {
							menuContent[i].item[j].item.push({
								itemIndex: tree[i].id + "-" + tree[i].son[j].son[k].parentid + "-" + tree[i].son[j].son[k].id,
								itemTitle: tree[i].son[j].son[k].name,
								url: tree[i].son[j].son[k].url
							});
						}
					}
				}
			}
		}
	}
	for (var j = 0; j < menuContent.length; j++) {
		for (var k = 0; k < menuContent[j].item.length; k++) {
			//			menuContent[j].item[k].itemIndex = menuContent[j].item[k].itemIndex + "-" + (k+1);
			if (menuContent[j].item[k].url) {
				a.push({
					key: menuContent[j].item[k].itemIndex,
					url: menuContent[j].item[k].url,
					index: menuContent[j].item[k].itemIndex.split("-")[0]
				});
			}
			if (menuContent[j].item[k].item) {
				for (var g = 0; g < menuContent[j].item[k].item.length; g++) {
					a.push({
						key: menuContent[j].item[k].item[g].itemIndex,
						url: menuContent[j].item[k].item[g].url,
						index: menuContent[j].item[k].item[g].itemIndex.split("-")[0]
					});
				}
			}
		}
	}
	that.hrefUrl = [];
	that.hrefUrl = a;
	console.log(menuContent)
	return menuContent;
}


/**
 * 自定义弹出框
 * @param {Object} Vue
 * @param {Object} element
 * @param {Object} $
 * @param {Object} that
 * @param {Object} content 内容
 * @param {Object} title 标题
 * @param {Object} sureBtnText 按钮文字
 */
function gzsaAlert(Vue, element, $, that, content, title, sureBtnText) {
	title = title == ("" || undefined || null) ? "提示" : title;
	sureBtnText = sureBtnText == ("" || undefined || null) ? "确定" : sureBtnText;
	that.$alert(content, title, {
		confirmButtonText: sureBtnText,
		callback: function action() {}
	});
}


/**
 * 数组去重
 * @param {Object} arr
 */
function arrUnique(arr) {
	var tmp = new Array();
	for (var i in arr) {
		if (tmp.indexOf(arr[i]) == -1) {
			tmp.push(arr[i]);
		}
	}
	return tmp;
}

function returnValue(label, options) {
	var value = "";
	if (isNaN(label)) {
		for (var i = 0; i < options.length; i++) {
			if (label == options[i].label) {
				value = options[i].value;
				break;
			}
		}
		return value;
	} else {
		return label;
	}
}

function returnLabel(value, options) {
	var label = "";
	if (isNaN(label)) {
		label = value;
		return label;
	} else {
		for (var i = 0; i < options.length; i++) {
			if (value == options[i].value) {
				label = options[i].label;
				break;
			}
		}
		return label;
	}
}

function returnDepartID(label, treedata) {
	for (var i = 0; i < treedata.length; i++) {
		if (label == treedata[i].label) {
			return treedata[i].dpno;
		}
		if (treedata[i].children) {
			for (var j = 0; j < treedata[i].children.length; j++) {
				if (label == treedata[i].children[j].label) {
					return treedata[i].children[j].dpno;
				}
				if (treedata[i].children[j].children) {
					for (var k = 0; k < treedata[i].children[j].children.length; k++) {
						if (label == treedata[i].children[j].children[k].label) {
							return treedata[i].children[j].children[k].dpno;
						}
					}
				}
			}
		}
	}
}

function returnDepartName(dpno, treedata) {
	for (var i = 0; i < treedata.length; i++) {
		if (dpno == treedata[i].dpno || dpno == 0) {
			return treedata[i].label;
		}
		if (treedata[i].children.length > 0) {
			for (var j = 0; j < treedata[i].children.length; j++) {
				if (dpno == treedata[i].children[j].dpno) {
					return treedata[i].children[j].label;
				}
				if (treedata[i].children[j].children.length > 0) {
					for (var k = 0; k < treedata[i].children[j].children.length; k++) {
						if (dpno == treedata[i].children[j].children[k].dpno) {
							return treedata[i].children[j].children[k].label;
						}
					}
				}
			}
		}
	}
}


function returnAreaselect(label, treedata) {
	for (var i = 0; i < treedata.length; i++) {
		if (label == treedata[i].label) {
			return treedata[i].subid;
		}
		if (treedata[i].children) {
			for (var j = 0; j < treedata[i].children.length; j++) {
				if (label == treedata[i].children[j].label) {
					return treedata[i].children[j].subid;
				}
				if (treedata[i].children[j].children) {
					for (var k = 0; k < treedata[i].children[j].children.length; k++) {
						if (label == treedata[i].children[j].children[k].label) {
							return treedata[i].children[j].children[k].subid;
						}
					}
				}
			}
		}
	}
}

/**
 * 密码强度检测
 * @param {Object} pass 密码
 */
function passStrength(pass) {
	var pwdtest1 = /^(?:\d+|[a-zA-Z]+|[!@#$%^&*]+){6,}$/; //  弱：纯数字，纯字母，纯特殊字符
	var pwdtest2 = /^(?![a-zA-z]+$)(?!\d+$)(?![!@#$%^&*]+$)[a-zA-Z\d!@#$%^&*]+$/; //中：字母+数字，字母+特殊字符，数字+特殊字符
	var pwdtest3 =
		/^(?![a-zA-z]+$)(?!\d+$)(?![!@#$%^&*]+$)(?![a-zA-z\d]+$)(?![a-zA-z!@#$%^&*]+$)(?![\d!@#$%^&*]+$)[a-zA-Z\d!@#$%^&*]+$/; //强：字母+数字+特殊字符
	var passStrength = 0;
	if (pwdtest1.test(pass)) {
		if (pwdtest2.test(pass)) {
			passStrength = 2;
			if (pwdtest3.test(pass)) {
				passStrength = 3;
			} else {
				passStrength = 2;
			}
		} else {
			passStrength = 1;
		}
	} else {
		passStrength = 1;
	}
	return passStrength;
}

function testIP(ip) {
	var regIP = new RegExp("^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\." +
		"(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\." + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\." +
		"(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$");
	return regIP.test(ip);
}

function testMAC(mac) {
	var regMac = new RegExp("([A-Fa-f0-9]{2}:){6}");
	console.log(mac)
	return regMac.test(mac);
}


//今天日期
function today() {
	var d = new Date();
	var day = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
	return day
}

//本周日期
function weekMonday() {
	var now = new Date();
	var nowTime = now.getTime();
	var day = now.getDay();
	var oneDayTime = 24 * 60 * 60 * 1000;
	var MondayTime = nowTime - (day - 1) * oneDayTime; //显示周一

	//console.log(new Date(MondayTime));

	var Monday = new Date(MondayTime)

	return formatDate(Monday, 0)

}

function weekSunday() {
	var now = new Date();
	var nowTime = now.getTime();
	var day = now.getDay();
	var oneDayTime = 24 * 60 * 60 * 1000;
	var SundayTime = nowTime + (7 - day) * oneDayTime; //显示周日
	//console.log(new Date(SundayTime))
	var Sunday = new Date(SundayTime)
	return formatDate(Sunday, 0)
}

//本月第一天和最后一天
var time = new Date().getTime();
function getCurrentMonthFirst() {
	var date = new Date();
	date.setDate(1);
	return  formatDate(date, 0);
}
// 获取当前月的最后一天
function getCurrentMonthLast() {
	var date = new Date();
	var currentMonth = date.getMonth();
	var nextMonth = ++currentMonth;
	var nextMonthFirstDay = new Date(date.getFullYear(), nextMonth, 1);
	var oneDay = 1000 * 60 * 60 * 24;
	var MonthLast=new Date(nextMonthFirstDay - oneDay);
    return formatDate(MonthLast, 0);
}



/*公共菜单栏*/
function commonMenuZ(Vue, defaultActive, isCollapse) {
	var commonMenu = new Vue({
		el: "#common-menu",
		data: {
			defaultActive: defaultActive,
			isCollapse: isCollapse,
			menuContent: '',

		},
		created: function() {

		},
		mounted: function() {
			var that = this;
			// 获取缓存的菜单数据
			var tree = sessionStorage.getItem("tree");
			if (tree) {
				tree = JSON.parse(tree);
				that.menuContent = tree;
			} else {
				// 接口获取菜单数据

				myAjax({
					url: server + "/user/menu",
					type: "post",
					beforeSend: function() {

					},
					complete: function() {

					},
					success: function(data) {
						if (data.code == 401) {
							errorPage(data.msg);
						} //登陆超时
						if (data.code == 200) {
							sessionStorage.setItem("tree", JSON.stringify(data.data));
							that.menuContent = data.data;

							console.log(data.data)
							console.log(that.menuContent);
						}
					},

				});
			}
		},
		methods: {
			handleOpen: function(key, keyPath) { // 展开二级菜单

			},
			handleClose: function(key, keyPath) { // 收起二级菜单

			},
			handleSelect: function(key, keyPath) { // 选择菜单
				console.log(this.menuContent)
				
				
				var arr = key.split('-');
				var len = arr.length;
				if (len == 1) {
					var url = this.menuContent[arr[0]].url;
					 location.href = url + "?w=" + this.isCollapse + "&o=" + arr[0] + '-' + arr[1];
					//location.href = url + "?w=" + this.isCollapse + "&sn=" + this.menuContent[arr[0]].sn;
				} else if (len == 2) {
					var url = this.menuContent[arr[0]].son[arr[1]].url;
					 location.href = url + "?w=" + this.isCollapse + "&o=" + arr[0] + '-' + arr[1];
					//location.href = url + "?w=" + this.isCollapse + "&sn=" + this.menuContent[arr[0]].sn;
				} else if (len == 3) {
					var url = this.menuContent[arr[0]].son[arr[1]].son[2].url;
					 location.href = url + "?w=" + this.isCollapse + "&o=" + arr[0] + '-' + arr[1] + arr[2];
					//location.href = url + "?w=" + this.isCollapse + "&sn=" + this.menuContent[arr[0]].sn;
				}
			}
		}
	});
}



 /*公共头部*/
function headercommon(Vue, element, $){
	
	var validateEmail = (rule, value, callback) => {
	        if (value === '') {
	          callback(new Error('请正确填写邮箱'));
	        } else {
	          if (value !== '') { 
	            var reg=/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
	            if(!reg.test(value)){
	              callback(new Error('请输入有效的邮箱'));
	            }
	          }
	          callback();
	        }
	      };
		  // 验证手机号
	var validateMobilePhone = (rule, value, callback) => {
		        if (value === '') {
		          callback(new Error('手机号不可为空'));
		        } else {
		          if (value !== '') { 
		            var reg=/^1[3456789]\d{9}$/;
		            if(!reg.test(value)){
		              callback(new Error('请输入有效的手机号码'));
		            }
		          }
		          callback();
		        }
		      };
	
	
	
	
	var header = new Vue({
		el: "#header",
		data: {
			isStartQuit: false,
			username: '',
			euditinfo:{
				name:'',
				real_name:'',
				phone:'',
				email:'',
				
			},
			password:{
				old_password:'',
				new_password:'',
				again_password:'',
			},
			 euditrules:{ //phone:[{required: true, validator: validateMobilePhone, trigger: 'blur'}],
			// 	 email:[{required: true,validator:validateEmail,  trigger: 'blur'}]
			},
			euditinfoVisible:false,
			passwordVisible:false,
			total:'',
			totaldata:[],
			seen:false,
	
		},
		created: function() {
	
		},
		mounted: function() {
			this.username = sessionStorage.getItem("who");
			this.userinfo();
			this.alarminfo();
		},
		methods: {
			logout: function() { // 展开二级菜单
				var that = this;
				if (this.isStartQuit == false) {
					this.isStartQuit = true;
					myAjax({
						url: server + "/user/logout",
	
						success: function(data) {
							if (data.code == 200) {
								sessionStorage.setItem("tree", "");
								sessionStorage.setItem("logo", "");
								window.location.href = "../index.html";
							}
							if (data.code == 401) { //登陆超时
								errorPage(data.msg);
							}
						},
						complete: function() {
	
							that.isStartQuit = false;
	
						}
					});
				}
			},
			userinfo:function(){
				var that = this;
				myAjax({
					url: server + "/user/info",
				   type: "GET",
					success: function(data) {
						if (data.code == 200) {
						
							
							that.euditinfo.name=data.data.name;
							that.euditinfo.real_name=data.data.real_name;
							that.euditinfo.phone=data.data.phone;
							that.euditinfo.email=data.data.email;
						}
						if (data.code == 401) { //登陆超时
							errorPage(data.msg);
						}
					},
					
				});
				
			},
			
			
			alarminfo:function(){
				var that = this;
				myAjax({
					url: server + "/operate/alarm_info",
				   type: "GET",
					success: function(data) {
						if (data.code == 200) {
						
						that.total=data.data.total;
							that.totaldata=data.data.data
						}
						if (data.code == 401) { //登陆超时
							errorPage(data.msg);
						}
					},
					
				});
				
			},
			enter(index){
			  this.seen = true;
			 
			},
			leave(){
			  
			
			 this.seen = false
			            
			  
			     
			},
			
			
			euditinfotion:function(){
				 this.euditinfoVisible=true
			},
			euditpassword:function(){
				  this.passwordVisible=true
			},
			
			euditinfoDev:function(euditinfo){
				
				         var that = this;
				
				
							myAjax({
								url: server + "/user/info",
								type: "PUT",
								data: {
									 phone: that.euditinfo.phone,
									email: that.euditinfo.email,
									real_name: that.euditinfo.real_name,
								},
								
								success: function(data) {
									if (data.code == 401) {
										errorPage(data.msg);
									} //登陆超时
									if (data.code == 200) {
										that.euditinfoVisible = false;
										that.$message({
											message: '修改成功',
											center: true,
											type: 'success'
										});
										
									}
									if (data.code == 405) {
										that.$message.error({
											message: data.msg,
											center: true
										});
									
									}
									if (data.code == 500) {
										that.$message.error({
											message: data.msg,
											center: true
										});
										
									}
									
								},
								
							});
						
			
				
				
			},
			passwordDev:function(password){
				
				var that = this;
				
				if(that.password.new_password!=that.password.again_password){
					
					
					that.$message({
						message: '输入新密码不一致，请重新输入!',
						center: true,
						type: 'warning'
					});
					return false
					
				}
				
				
				
				myAjax({
					url: server + "/user/password",
					type: "PUT",
					data: {
						old_password: encrypt(that.password.old_password),
						new_password: encrypt(that.password.new_password),
						
					},
					
					success: function(data) {
						if (data.code == 401) {
							errorPage(data.msg);
						} //登陆超时
						if (data.code == 200) {
							that.passwordVisible = false;
							that.$message({
								message: '修改成功',
								center: true,
								type: 'success'
							});
							
						}
						if (data.code == 405) {
							that.$message.error({
								message: data.msg,
								center: true
							});
						
						}
						if (data.code == 404) {
							that.$message.error({
								message: data.msg,
								center: true
							});
							that.passwordVisible = false;
						
						}
						if (data.code == 500) {
							that.$message.error({
								message: data.msg,
								center: true
							});
							
						}
						
					},
					
				});
				
				
			},
			
		}
	})
	
}
